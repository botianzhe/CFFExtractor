from .face_utils import norm_crop, FaceDetector
import os
import numpy as np
from PIL import Image
from torchvision import transforms as T

print(os.getcwd())
face_detector = FaceDetector()

face_detector.load_checkpoint("model/model_save/RetinaFace-Resnet50-fixed.pth")

def extract_frames(video_path):
    """
    Extract frames from a video. You can use either provided method here or implement your own method.

    params:
        - video_local_path (str): the path of video.
    return:
        - frames (list): a list containing frames extracted from the video.
    """
    ########################################################################################################
    # You can change the lines below to implement your own frame extracting method (and possibly other preprocessing),
    # or just use the provided codes.
    import cv2
    vid = cv2.VideoCapture(video_path)
    cap=vid.get(cv2.CAP_PROP_FRAME_COUNT)
    frames = []
    detect_per_video=32
    i=0
    while True:
        success = vid.grab()
        if not success:
            break
        if i%(cap//detect_per_video)==0:
            success,frame=vid.retrieve()
            if frame is not None:
                boxes, landms = face_detector.detect(frame)
                if boxes.shape[0] == 0:
                    continue
                areas = (boxes[:, 3] - boxes[:, 1]) * (boxes[:, 2] - boxes[:, 0])
                order = areas.argmax()
                boxes = boxes[order]
                landms = landms[order]
                # Crop faces
                landmarks = landms.numpy().reshape(5, 2).astype(np.int)
                img = norm_crop(frame, landmarks, image_size=320)
                # img=cv2.resize(img,(224,224))
                aligned=T.ToTensor()(img)
                frames.append(aligned)
        i+=1
    vid.release()
    return frames
    ########################################################################################################
